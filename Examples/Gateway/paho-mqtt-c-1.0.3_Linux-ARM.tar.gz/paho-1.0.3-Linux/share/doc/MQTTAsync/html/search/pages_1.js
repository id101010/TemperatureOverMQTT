var searchData=
[
  ['publication_20example',['Publication example',['../publish.html',1,'']]]
];
