var searchData=
[
  ['subscription_20example',['Subscription example',['../subscribe.html',1,'']]],
  ['subscription_20wildcards',['Subscription wildcards',['../wildcard.html',1,'']]]
];
