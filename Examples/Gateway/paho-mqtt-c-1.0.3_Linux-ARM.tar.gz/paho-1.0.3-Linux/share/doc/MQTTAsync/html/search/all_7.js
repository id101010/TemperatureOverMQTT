var searchData=
[
  ['onfailure',['onFailure',['../struct_m_q_t_t_async__response_options.html#a09ce26d7cff24e14a6844eaae7b15290',1,'MQTTAsync_responseOptions::onFailure()'],['../struct_m_q_t_t_async__connect_options.html#a09ce26d7cff24e14a6844eaae7b15290',1,'MQTTAsync_connectOptions::onFailure()'],['../struct_m_q_t_t_async__disconnect_options.html#a09ce26d7cff24e14a6844eaae7b15290',1,'MQTTAsync_disconnectOptions::onFailure()']]],
  ['onsuccess',['onSuccess',['../struct_m_q_t_t_async__response_options.html#ac13fb68f736854fcab131b34756bfceb',1,'MQTTAsync_responseOptions::onSuccess()'],['../struct_m_q_t_t_async__connect_options.html#ac13fb68f736854fcab131b34756bfceb',1,'MQTTAsync_connectOptions::onSuccess()'],['../struct_m_q_t_t_async__disconnect_options.html#ac13fb68f736854fcab131b34756bfceb',1,'MQTTAsync_disconnectOptions::onSuccess()']]]
];
