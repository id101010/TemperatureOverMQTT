var searchData=
[
  ['qentry',['qEntry',['../structqEntry.html',1,'']]]
];
