var searchData=
[
  ['unsubscribe',['Unsubscribe',['../structUnsubscribe.html',1,'']]]
];
