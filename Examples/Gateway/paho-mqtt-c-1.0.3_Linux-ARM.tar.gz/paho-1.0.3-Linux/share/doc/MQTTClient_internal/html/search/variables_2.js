var searchData=
[
  ['buflen',['buflen',['../structsocket__queue.html#ab38f6d48de7c8905c3124ee1de4eac71',1,'socket_queue']]],
  ['byte',['byte',['../unionHeader.html#a75d550e644fb0f4ae2be1a33d0d89ec6',1,'Header']]],
  ['bytes',['bytes',['../utf-8_8c.html#ab79808430aab9d7a9de5581bbe538ebe',1,'utf-8.c']]]
];
