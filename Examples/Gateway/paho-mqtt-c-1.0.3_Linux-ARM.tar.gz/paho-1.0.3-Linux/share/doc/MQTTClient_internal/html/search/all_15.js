var searchData=
[
  ['valid_5franges',['valid_ranges',['../utf-8_8c.html#ab89277c717563ff8748b7c3204f7ad06',1,'utf-8.c']]],
  ['version',['version',['../structConnect.html#a35cba4252092877e572c5c74b41be6e2',1,'Connect']]]
];
