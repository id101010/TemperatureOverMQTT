var searchData=
[
  ['datalen',['datalen',['../structsocket__queue.html#a812ce9bb00766c3e91a593842414b693',1,'socket_queue']]],
  ['def_5fqueue',['def_queue',['../SocketBuffer_8c.html#ace376d23d15b97a487298fa0c8a238ea',1,'SocketBuffer.c']]],
  ['dup',['dup',['../structMQTTAsync__message.html#aa9da73253863089ee90033c7f0dd28bf',1,'MQTTAsync_message::dup()'],['../structMQTTClient__message.html#abbb5f23377bd9f39cc79756786fa45cc',1,'MQTTClient_message::dup()'],['../unionHeader.html#a35c1c5537424b9307f4ff0803f16a25f',1,'Header::dup()']]]
];
