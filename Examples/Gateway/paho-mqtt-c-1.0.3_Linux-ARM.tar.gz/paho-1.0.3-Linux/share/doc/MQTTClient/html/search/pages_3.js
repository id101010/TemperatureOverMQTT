var searchData=
[
  ['synchronous_20publication_20example',['Synchronous publication example',['../pubsync.html',1,'']]],
  ['subscription_20wildcards',['Subscription wildcards',['../wildcard.html',1,'']]]
];
